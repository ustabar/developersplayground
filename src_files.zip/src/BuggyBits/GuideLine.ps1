Install-WindowsFeature -Name Containers

Uninstall-WindowsFeature Windows-Defender

Restart-Computer -Force  

Install-Module -Name DockerMsftProvider -Repository PSGallery -Force

Install-Package -Name docker -ProviderName DockerMsftProvider -Force -RequiredVersion 19.03  

Start-Service docker

docker image pull mcr.microsoft.com/windows/servercore:ltsc2019

docker image pull mcr.microsoft.com/windows/nanoserver:1809

iwr https://aka.ms/Debug-ContainerHost.ps1 -useb | iex

docker swarm init --advertise-addr 127.0.0.1  

iwr -useb -outf docker-stack-windows-1809.yml https://raw.githubusercontent.com/sixeyed/example-voting-app/master/docker-stack-windows-1809.yml

docker stack deploy -c .\docker-stack-windows-1809.yml vote  

docker service ls

docker service ps xxxxx --no-trunc

# docker compose setup
# https://docs.docker.com/compose/install/

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest "https://github.com/docker/compose/releases/download/1.25.4/docker-compose-Windows-x86_64.exe" -UseBasicParsing -OutFile $Env:ProgramFiles\Docker\docker-compose.exe
docker-compose --version

# PS C:\Source\DockerSwarm\src> docker-compose up
# http://localhost:56077/

docker stack deploy -c docker-compose-test.yml demo

# from remote host :       http://137.135.108.230:8787/