﻿using Microsoft.AspNetCore.Html;

namespace BuggyBits.ViewModels
{
    public class AllProductsViewModel
    {
        public IHtmlContent ProductsTable { get; set; }
    }
}
